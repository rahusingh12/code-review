<?php
$date=date_create($dayOnTime[0]['requested_date']);

?>
<div class="page-container">
    <div class="container">
        <div class="page-title-container">
            <div class="page-heading">Request For Quote - Sumbitted!</div>
            <div class="progress form-progress-bar">
                <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                </div>
            </div>
            <form class="form-container">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="form-card-container">
                            <div class="page-heading">Your Request For Quote Has Been Submitted!</div>
                            <div class="form-set-content">
                                You wil be able to access your <b>Quote</b> at <b><?php echo date_format($date,"H:i A"); ?></b> on <b><?php echo date_format($date,"dS F Y"); ?>.</b> <br><br>
                                * Please sign in to My TERANEX go to Dashboard, and select <b>Launch Button under Quotes</b> on the date and time specified above.
                            </div>
                        </div>
                    </div>
                </div>
               
            </form>
        </div>
    </div>
</div>
<div class="page-container">
        <div class="container">
            <div class="page-title-container">
                <div class="page-heading">Quote Request- Additive Manufacturing</div>
                <div class="progress form-progress-bar">
                    <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                    </div>
                </div>
                <form class="form-container">
                    <div class="row justify-content-center">
                        <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8">
                            <div class="form-card-container">
                                <div class="form-set-content p-0">
                                    <table class="table table-bordered mb-0 time-study-table" style="width:100%">
                                        <tbody>
                                            <tr>
                                                <td width="45%">Part Id</td>
                                                <th width="55%"><?php echo  $wicam['dataWicam']['fileID']?></th>
                                            </tr>
                                            <tr>
                                                <td>Material</td>
                                                <th><?php echo  $wicam['dataWicam']['material']?></th>
                                            </tr>
                                            <tr>
                                                <td>Thickness</td>
                                                <th><?php echo $wicam['dataWicam']['thickness']?></th>
                                            </tr>
                                            <tr>
                                                <td>Length</td>
                                                <th><?php echo $wicam['dataWicam']['length']?></th>
                                            </tr>
                                            <tr>
                                                <td>Width</td>
                                                <th><?php echo $wicam['dataWicam']['width']?></th>
                                            </tr>
                                            <tr>
                                                <td>Net Area</td>
                                                <th><?php echo $wicam['dataWicam']['nettoArea']?></th>
                                            </tr>
                                            <tr>
                                                <td>Gross Area</td>
                                                <th><?php echo $wicam['dataWicam']['area']?></th>
                                            </tr>
                                            <tr>
                                                <td>Cuts</td>
                                                <th><?php echo $wicam['dataWicam']['cuts']?></th>
                                            </tr>
                                            <tr>
                                                <td>Bends</td>
                                                <th><?php echo $wicam['dataWicam']['bends']?></th>
                                            </tr>
                                            <tr>
                                                <td>Net Weight</td>
                                                <th><?php echo $wicam['dataWicam']['nettoWeight']?></th>
                                            </tr>
                                            <tr>
                                                <td>Gross Weight</td>
                                                <th><?php echo $wicam['dataWicam']['weight']?></th>
                                            </tr>
                                            <tr>
                                                <td>Cut Length</td>
                                                <th><?php echo $wicam['dataWicam']['cutLength']?></th>
                                            </tr>
                                            <tr>
                                                <td>Deburring</td>
                                                <th><?php echo $wicam['dataWicam']['deburring']?></th>
                                            </tr>
                                            <tr>
                                                <td>Grinding</td>
                                                <th><?php echo $wicam['dataWicam']['grinding']?></th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-card-container time-study-total d-flex font-20">
                                <span class="d-flex flex-column time-study-total-set">
                                    <span class="time-box">03</span>
                                    <span>Mins</span>
                                </span>
                                <span class="time-box-sep">:</span>
                                <span class="d-flex flex-column time-study-total-set">
                                    <span class="time-box">36</span>
                                    <span>Seconds</span>
                                </span>
                            </div>
                            <div class="submit-btn-container">
                    <a href="<?php echo site_url() . "digitalmanufacturing/"?>" class="btn submit-btn">Back To Digital Manufacturing</a>
                </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
         
                


