
<div class="page-container">
    <div class="container">
        <div class="page-title-container">
            <div class="page-heading">Request For Quote - Manufacturing On-Demand</div>
            <div class="progress form-progress-bar">
                <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:25%">
                </div>
            </div>
            <form class="form-container" action="<?php echo site_url().'additivemanufacturing/additive_manufacturingRFQSelect'; ?>" method="post" id="form1">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="form-card-container flex justify-spacebetween align-items-center">
                            <div class="page-heading">Select a Technology</div>
                            <div class="submit-btn-container no-padding select-tech-radio d-flex flex-md-wrap flex-lg-nowrap">
                                <!-- <button class="btn gray-outline-btn">For Sheet Metals</button>
                                <button class="btn gray-outline-btn">3D Printing</button>
                                <button class="btn gray-outline-btn">CNC Machining</button> -->
                                <div class="radio custom-radio-check">
                                    <input type="radio" name="radio1" id="radio1" value="sheet-metal">
                                    <label for="radio1" class="btn gray-outline-btn my-lg-0">
                                        Sheet Metal
                                    </label>
                                </div>
                                <div class="radio custom-radio-check">
                                    <input type="radio" name="radio1" id="radio2" value="3d-print">
                                    <label for="radio2" class="btn gray-outline-btn my-lg-0">
                                        3D Printing
                                    </label>
                                </div>
                                <div class="radio custom-radio-check">
                                    <input type="radio" name="radio1" id="radio3" value="cnc-machine">
                                    <label for="radio3" class="btn gray-outline-btn my-lg-0">
                                        CNC Machining
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="submit-btn-container">
                    <button href="" class="btn submit-btn" type="submit" form="form1" value="Submit">Next</button>
                </div>
            </form>
        </div>
    </div>
</div>