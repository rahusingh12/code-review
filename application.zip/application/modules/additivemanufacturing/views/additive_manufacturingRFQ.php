<?php
$user_id = $this->session->userdata('uid');
?>
<style>
    .tab {
        display: none;
    }
    .tab1{
        display:block;
    }
</style>
<!-- Body container Start -->
<div class="page-container">
    <div class="container">
        <div class="page-title-container">

            <!-- // display messages -->
            <?php if(hasFlash("dataMsgError")) { ?>
                <div class="alert alert-warning alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <?php echo getFlash("dataMsgError"); ?>
                </div>
            <?php } ?>

            <form class="form-container" name="#" method="post" action="" enctype="multipart/form-data">
                <div class="tab tab1">
                    <div class="page-heading">Request For Quote - On-Demand Manufacturing</div>
                    <div class="progress form-progress-bar">
                        <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                        </div>
                    </div>

                    <div class="Time-study-form-container">
                        <div class="row col-grid">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                                <div class="form-card-container part-of-information">
                                    <div class="page-heading">Part Information</div>
                                    <div class="form-set-content">
                                        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 no-padding">
                                            <div class="form-group">
                                                <input class="input-control form-control" type="text" placeholder="Part 1 Name" id="part_name" name="part_name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-set-content">
                                        <label >Material Type</label>
                                        <select class="form-select-box" id="material" name="material">
                                            <option value="">Please Select</option>
                                            <?php foreach($material as $value) { ?>
                                                <option value="<?php echo $value?>"><?php echo $value?></option>
                                            <? } ?>
                                        </select>
                                    </div>
                                    <!-- <div class="form-set-content">
                                        <label>Application Type</label>
                                        <select class="form-select-box" name="application_required" id="application_required">
                                              <option value="">Please Select</option>
                                            <?php foreach($application_required as $rowData) { ?>
                                                <option value="<?php echo $rowData['aid']; ?>"><?php echo $rowData['type_name']?> </option>
                                            <? } ?>
                                        </select>
                                    </div> -->

                                    <div class="form-set-content">
                                        <label>Thickness</label>
                                        <select class="form-select-box" name="thickness">
                                            <?php foreach($thickness as $value) { ?>
                                                <option value="<?php echo $value?>"><?php echo $value?></option>
                                            <? } ?>
                                        </select>
                                    </div>

                                    <div class="form-set-content">
                                        <label>Rotation</label>
                                        <select class="form-select-box" name="rotation">
                                            <option value="">Please Select</option>
                                            <?php foreach($rotation as $value) { ?>
                                                <option value="<?php echo $value?>"><?php echo $value?></option>
                                            <? } ?>
                                        </select>
                                    </div>

                                    <div class="form-set-content d-flex align-items-center">
                                        <label class="no-wrap">Number of Parts</label>
                                            <div class="number-of-parts">
                                              <button type="button" class="down_count btn btn-info mx-2" title="Down"><i class="ion-android-remove"></i></button>
                                              <input class="counter input-control w-25" type="text" name="no_of_parts" placeholder="value..." value="0">    
                                              <button type="button" class="up_count btn btn-info mx-2" title="Up"><i class="ion-android-add"></i></button>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                                <div class="form-card-container">
                                    <div class="page-heading">Attach Drawings</div>
                                    <div class="form-set-content">
                                        <label class="full-width">Part 1</label>
                                        <div class="file-browser">
                                            <span class="control-fileupload">
                                                <label for="file"></label>
                                                <input type="file" id="file" name="attach_drawing" onchange="return fileValidation()" required />
                                            </span>
                                        </div>
                                        
                                    </div>
                                    <div class="form-set-content">
                                        <div class="form-group flex">
                                            <label>Description</label>
                                            <textarea class="flex form-control" placeholder="Ender your part description here.." rows="4" id="part_description" name="part_description"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="remove-Time-study-form">
                            <i class="fa fa-close"></i>
                            <span>Remove</span>
                        </div>
                    </div>
                    <div class="Time-study-form-clone part-of-information-card-container"></div>
                    <div class="add-new-part add-Time-study-form">
                        <i class="fa fa-plus-square"></i>
                        <span>Add New</span>
                    </div>
                    <div class="submit-btn-container">
                      <a href="<?php echo site_url()."digitalmanufacturing/"?>" class="btn back-btn">Go Back</a>
                
                       <!-- <button type="submit" class="btn submit-btn" name="btnRfq" id="btnRfq" value="Submit RFQ">Submit!</button>-->
                        <button type="button" name="btnRfq" id="n1" class="btn submit-btn">Next</button>
                    </div>

                </div>
                <div class="tab tab2">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-heading">Request For Quote - Agreements</div>
                            <div class="progress form-progress-bar">
                                <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                                </div>
                            </div>
                        </div>


                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="form-card-container">
                                <div class="page-heading">Non - Disclosure</div>
                                <div class="radio custom-radio-check">
                                    <input type="radio" name="nda_required" value="N" id="radio12">
                                    <label for="radio12">
                                        No NDA Required <br>
                                        <small class="font-13">
                                            ( Allow suppliers to view and quote on the RFQ )
                                        </small>
                                    </label>
                                </div>
                                <div class="radio custom-radio-check">
                                    <input type="radio" name="nda_required" value="Y" id="radio21">
                                    <label for="radio21">
                                        NDA Required <br>
                                        <small class="font-13">
                                            ( Suppliers must sign NDA before viewing and quoting on this RFQ )
                                        </small>
                                    </label>
                                </div>
                                <div class="form-set-content">
                                    <div class="file-browser">
                                        <span class="control-fileupload">
                                            <label for="file"></label>
                                            <input type="file" id="fileUpload" name="nda_file">
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="submit-btn-container">
                        <!-- <button type="button"  class="btn back-btn" onclick="nextPrev('.tab1','.tab2')">Go Back</button>
                        <button type="button" name="btnRfq"  class="btn submit-btn" id="n2">Next</button> -->
                        <button type="button" class="btn back-btn" onclick="nextPrev('.tab2','.tab3')">Go Back</button>
                      <input type="submit" class="btn submit-btn" name="btnRfq" id="n2" value="Submit!">
                    </div>
                </div>
            </form>
        </div>
   </div>
</div>
<!-- Body container End -->

<?php $this->template->contentBegin(POS_BOTTOM);?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.min.js"></script>
<!-- <script src="<?=$theme_url?>/js/jquery.validate.min.js"></script>   -->
<script type="text/javascript">
$(function() {
           $(".datepicker").datepicker({ dateFormat: "yy-mm-dd", minDate: 0,changeYear: true,yearRange: "-70:+0" }).val()
   });


		function nextPrev(showClass,hideClass){
	        $(showClass).show();
	        $(hideClass).hide();
	    }
		</script>
    <script type="text/javascript">
      $("#n1").click(function () {
                var clikedForm = $(this); // Select Form


                if ($('#part_name').val() == '') {

                    alert('Enter Part Name');
                    $('.tab1').show();
                    return false;
                }

                else if ($('#file').val() == '') {

                    alert('Please Upload Image');
                    $('.tab1').show();
                    return false;
                }
                
                else{
                    $('.tab1').hide();
                    $('.tab2').show();

                }


            });
      $("#n2").click(function () {
                var clikedForm = $(this); // Select Form
                var fileInput = document.getElementById('fileUpload');
                var filePath = fileInput.value;
                var allowedExtensions = /(\.pdf)$/i;


                if ($('input[type=radio][name=nda_required]:checked').length==0 ) {


                    alert('Select One Non Disclosure Option');
                    $('.tab2').show();
                   // return false;
                }

                else if(!allowedExtensions.exec(filePath)){
                alert('Please upload file having extensions .pdf only.');
                fileInput.value = '';
                return false;
            }


                else{
                    

                }


            });
      $("#btnRfq").click(function () {
                var clikedForm = $(this); // Select Form

                if ($('input[type=radio][name=fin_type]:checked').length==0 ) {
                  alert('Please Upload Required Data');
                    $('.tab3').show();
                   return false;
                }


                else{

                }


            });


      function fileValidation(){
        var fileInput = document.getElementById('file');
        var filePath = fileInput.value;
        var allowedExtensions = /(\.dwg|\.dxf)$/i;
        if(!allowedExtensions.exec(filePath)){
            alert('Please upload file having extensions .dwg/.dxf  only.');
            fileInput.value = '';
            return false;
        }else{
        }
    }
</script>

<script type="text/javascript">
$(document).ready(function(){
    $('button').click(function(e){
        var button_classes, value = +$('.counter').val();
        button_classes = $(e.currentTarget).prop('class');        
        if(button_classes.indexOf('up_count') !== -1){
            value = (value) + 1;            
        } else {
            value = (value) - 1;            
        }
        value = value < 0 ? 0 : value;
        $('.counter').val(value);
    });  
    $('.counter').click(function(){
        $(this).focus().select();
    });
});
</script>
<?php echo $this->template->contentEnd();?>




