<form name="#" id="#" method="post" enctype="multipart/form-data">
  <div class="row">
      <div class="col-12">
          <div class="page-heading">Request For Quote - Financing</div>
          <div class="progress form-progress-bar">
              <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
              </div>
          </div>
      </div>
      <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="form-card-container flex justify-spacebetween align-items-center">
              <div class="page-heading">Do You Require Financing?</div>
              <div class="submit-btn-container no-padding">
                  <button class="btn back-btn">Learn More</button>
                  <button class="btn submit-btn">Yes</button>
                  <button class="btn submit-btn">No</button>
              </div>
          </div>
      </div>
      <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
          <div class="form-card-container">
              <div class="page-heading">Finance Type</div>
              <div class="form-set-content no-padding">
                  <div class="radio radio-FinTech">
                      <input type="radio" name="fin_type" id="radio1" value="option1" checked="">
                      <label for="radio1">
                          Working Capital
                      </label>
                  </div>
                  <div class="radio radio-FinTech">
                      <input type="radio" name="fin_type" id="radio2" value="option2">
                      <label for="radio2">
                          Invoice Discounting
                      </label>
                  </div>
                  <div class="radio radio-FinTech">
                      <input type="radio" name="fin_type" id="radio2a" value="option2">
                      <label for="radio2a">
                          Purchase Order Financing
                      </label>
                  </div>

              </div>
          </div>
      </div>
      <div class="col-12 col-sm-12 col-md-8 col-lg-8 col-xl-8">
          <div class="form-card-container">
              <div class="page-heading">Required Documents</div>
              <div class="form-set-content">
                  To see more detailed description of the documents we require to approve your finance, read more below.
              </div>
              <div class="form-set-content">
                  <button class="btn submit-btn">Learn More</button>
              </div>
          </div>
          <div class="form-card-container">
              <div class="page-heading">Personal eKYC</div>
              <div class="form-set-content">
                  <label  class="full-width">Your Aadhaar</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file1"></label>
                          <input type="file" id="file1" name="personal_adhar_card">
                      </span>
                  </div>
              </div>
              <div class="form-set-content">
                  <label  class="full-width">Your PAN</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file2"></label>
                          <input type="file" id="file2" name="personal_pan_card">
                      </span>
                  </div>
              </div>
              <div class="form-set-content">
                  <label  class="full-width">Your Proof of Address</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file3"></label>
                          <input type="file" id="file3" name="personal_address_proof">
                      </span>
                  </div>
              </div>
          </div>
          <div class="form-card-container">
              <div class="page-heading">Business eKYC</div>
              <div class="form-set-content">
                  <label  class="full-width">Your PAN</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file4"></label>
                          <input type="file" id="file4" name="business_pan_card">
                      </span>
                  </div>
              </div>
              <div class="form-set-content">
                  <label  class="full-width">Your Proof of Address</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file5"></label>
                          <input type="file" id="file5" name="business_address_proof">
                      </span>
                  </div>
              </div>
          </div>
          <div class="form-card-container">
              <div class="page-heading">Company Documents</div>
              <div class="form-set-content">
                  <label  class="full-width">Bank Statement</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file6"></label>
                          <input type="file" id="file6" name="company_bank_statement">
                      </span>
                  </div>
              </div>
              <div class="form-set-content">
                  <label  class="full-width">Balance Sheet</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file7"></label>
                          <input type="file" id="file7" name="company_balance_sheet">
                      </span>
                  </div>
              </div>
              <div class="form-set-content">
                  <label  class="full-width">Invoice</label>
                  <div class="file-browser">
                      <span class="control-fileupload">
                          <label for="file8"></label>
                          <input type="file" id="file8" name="company_invoice_sheet">
                      </span>
                  </div>
              </div>
          </div>
      </div>
    </div>
  <div class="submit-btn-container">
    <button type="button" class="btn back-btn" >Go Back</button>
    <button type="button"  name="btnRfq1" class="btn submit-btn" >Next</button>
  </div>
</form>
