<?php
$this->db->select('*');
$data = $this->db->get('mst_country');
$country = $data->result_array();
?>
<!-- Body container Start -->
<div class="page-container">
    <div class="container">
        <div class="page-title-container">
            <div class="page-heading">Payment - Your Details</div>
            <div class="progress form-progress-bar">
                <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%"></div>
            </div>
            <form class="form-container" method="post" name="myform" onsubmit="return validateform()">
                <div class="row col-grid">
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-card-container">
                            <div class="page-heading">Billing Details</div>
                            <div class="Payment-signin-form-content">
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padding">
                                    <div class="form-group">
                                        <input class="input-control form-control" type="text" name="fname" placeholder="First Name">
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12  no-padding">
                                    <div class="form-group">
                                        <input class="input-control form-control" type="text" name="lname" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padding">
                                    <div class="form-group">
                                        <input class="input-control form-control" type="text" name="cname" placeholder="Company Name">
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padding">
                                    <div class="form-group">
                                        <input class="input-control form-control" type="text" name="address1" id="address1" placeholder="Address 1">
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padding">
                                    <div class="form-group">
                                        <input class="input-control form-control" type="text" name="address2" id="address2" placeholder="Address 2">
                                    </div>
                                </div>
                                <div class="full-width">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                            <div class="form-group">
                                                <input class="input-control form-control" type="text" name="city" id="city" placeholder="City">
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                            <div class="form-group">
                                                <input class="input-control form-control" type="text" name="state" id="state" placeholder="State">
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                            <div class="form-group">
                                                <input class="input-control form-control" type="text" name="postcode" id="postcode" placeholder="Postcode">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-set-content">
                                    <label>Country</label>
                                    <select class="form-select-box" name="country" id="country">
                                        <option value="1">Select Country</option>
                                        <?php
                                        if (isset($country)) {
                                            foreach ($country as $country_name) {
                                                ?>
                                                <option value="<?=$country_name['country_name']?>"><?=$country_name['country_name']?></option>
                                            <?php }
                                        } ?>
                                    </select>
                                </div>
                            </div>
                            </div>
                        </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-card-container">
                                <div class="page-heading">Delivery Address</div>
                                <div class="form-set-content pb-0">
                                    <div class="checkbox checkbox-warning">
                                        <input id="checkbox1" type="checkbox" name="" onchange="copyTextValue(this);" class="myCheckbox" data-target="firstDiv">
                                        <label for="checkbox1" name="myCheckbox">
                                            Same as Billing Address
                                        </label>
                                    </div>
                                </div>
                                <div class="Payment-signin-form-content"  name="target">
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padding">
                                        <div class="form-group">
                                            <input class="input-control form-control" type="text" name="delivery_add1" id="delivery_add1" placeholder="Address 1">
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padding">
                                        <div class="form-group">
                                            <input class="input-control form-control" name="delivery_add2" id="delivery_add2" type="text" placeholder="Address 2">
                                        </div>
                                    </div>
                                    <div class="full-width">
                                        <div class="row">
                                            <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                                <div class="form-group">
                                                    <input class="input-control form-control" name="delivery_city" id="delivery_city" type="text" placeholder="City">
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                                <div class="form-group">
                                                    <input class="input-control form-control" type="text" id="delivery_state" name="delivery_state" placeholder="State">
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                                <div class="form-group">
                                                    <input class="input-control form-control" type="text" name="delivery_postcode" id="delivery_postcode" placeholder="Postcode">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-set-content">
                                        <label>Country</label>
                                        <select class="form-select-box" name="delivery_country" id="delivery_country">
                                            <option value="1">Select Country</option>
                                                <?php
                                                if (isset($country)) {
                                                    foreach ($country as $country_name) {
                                                        ?>
                                                        <option value="<?=$country_name['country_name']?>"><?=$country_name['country_name']?></option>
                                                    <?php }
                                                } ?>
                                        </select>
                                    </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="submit-btn-container">
                     <input type="hidden" value="<?php echo $Finalamount['SubINR1']; ?>" name="amount">
                    <button class="btn back-btn">Go Back</button>
                    <button type="submit" class="btn submit-btn" name="submitData">Next</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script src="http://code.jquery.com/jquery-1.6.2.min.js"></script>
<script type="text/javascript">

    function validateform(){  
        var fname=document.myform.fname.value;  
         
        if (fname==null || fname==""){  
          alert("Please Enter the Billing/Delivery Address");  
          return false;  
        }
        } 

    $(document).on('click', '.myCheckbox', function () {
        var target = $(this).data('target');
        if ($(this).is(':checked')) {
            $('#' + target).addClass('disabled').css('pointerEvents','none');
        }
        else {
            $('#' + target).removeClass('disabled').css('pointerEvents','auto');
        }
    });


    function copyTextValue(bf) {
        var address1 = bf.checked ? document.getElementById("address1").value : '';
        var address2 = bf.checked ? document.getElementById("address2").value : '';
        var city = bf.checked ? document.getElementById("city").value : '';
        var state = bf.checked ? document.getElementById("state").value : '';
        var postcode = bf.checked ? document.getElementById("postcode").value : '';
        var country = bf.checked ? document.getElementById("country").value : '';
        document.getElementById("delivery_add1").value = address1;
        document.getElementById("delivery_add2").value = address2;
        document.getElementById("delivery_city").value = city;
        document.getElementById("delivery_state").value = state;
        document.getElementById("delivery_postcode").value = postcode;
        document.getElementById("delivery_country").value = country;
    }
</script>
</body>

</html>











































































































































