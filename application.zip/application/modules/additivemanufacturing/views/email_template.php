<style type="text/css">
/* Body Container style Start */
::before{
    box-sizing:border-box;
    g:border-box;
}

table {
    border-collapse: collapse;
}
.page-container {
    width: 100%;
    float: left;
    padding: 30px 0;
    padding-top: 50px;
}

.page-title-container {
    width: 100%;
    float: left;
}

.page-title-container .page-heading {
    width: 100%;
    float: left;
    color: #000;
    font-size: 30px;
    line-height: 30px;
    font-weight: bold;
    text-align: center;
}

.Time-study-form-container {
    width: 100%;
    float: left;
    position: relative;
}

.form-progress-bar {
    width: 100%;
    float: left;
    height: 8px;
    background-color: #b0bfc6;
    margin: 25px 0;
}

.form-progress-bar .progress-bar {
    line-height: 8px;
    background-color: #6acb62;
    box-shadow: none;
}

.form-container {
    width: 100%;
    float: left;
    padding-top: 30px;
}

.form-card-container {
    width: 100%;
    float: left;
    margin: 15px 0;
    padding: 40px 40px;
    box-shadow: 0px 0px 5px rgba(128, 142, 149, 0.75);
    position: relative;
    /* min-height: 92%; */
}

.form-card-container .form-set-content:last-child {
    padding-bottom: 0;
}

.form-card-container .form-set-content:last-child .form-group {
    margin-bottom: 0;
}

.form-card-container .form-set-content:last-child {
    padding-bottom: 0;
}

.form-card-container .form-set-content:last-child .form-group {
    margin-bottom: 0;
}

.form-card-container .form-set-content:last-child .col-12 .form-group {
    margin-bottom: 15px;
}

.form-card-container .form-set-content:last-child {
    padding-bottom: 0;
}

.form-card-container .form-set-content:last-child .form-group {
    margin-bottom: 0;
}

.form-card-container .form-set-content:last-child .col-12 .form-group {
    margin-bottom: 15px;
}


.part-of-information-card-container .form-card-container {
    /* margin: 35px 0; */
    margin: 15px 0;
}

.part-of-information-card-container .form-card-container:last-child {
    margin-bottom: 15px;
}

.form-card-container .form-set-content:last-child .radio:last-child {
    margin-bottom: 0;
}

.form-card-container .form-set-content:last-child .radio:last-child {
    margin-bottom: 0;
}

.form-card-container .form-set-content:last-child .radio:last-child {
    margin-bottom: 0;
}

.form-card-container .form-set-content:last-child .radio:last-child {
    margin-bottom: 0;
}

.form-card-container .page-heading {
    text-align: left;
}

.form-set-content {
    width: 100%;
    float: left;
    padding: 15px 0;
    font-size: 18px;
    font-weight: 300;
}

.form-set-content label {
    float: left;
    font-size: 18px;
    font-weight: 300;
    margin-right: 20px;
    margin-bottom: 0px;
}


.quote-timeline .form-set-content {
    margin-right: 30px;
}

.quote-timeline .form-set-content {
    width: auto;
}

.quote-timeline .form-set-content label {
    margin-bottom: 0;
}


.form-card-container.quote-timeline .form-set-content:last-child {
    padding-bottom: 15px;
}

.form-card-container.quote-timeline .form-set-content:last-child {
    padding-bottom: 15px;
}

.cart-total .form-card-container ul li {
    padding: 6px 0px;
}

/* .quote-timeline .flex.align-items-center {
    flex-wrap: wrap;
} */

/* Body Container style End */
</style>
<div class="page-container">
        <div class="container">
            <div class="page-title-container">
                <div class="page-heading">Quote Request - Additive Manufacturing</div>
                <div class="progress form-progress-bar">
                    <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                    </div>
                </div>
                    <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8">
                        <div class="form-card-container">
                            <div class="form-set-content">
                                <table style="width:100%">
                                    <tbody>
                                            <tr>
                                                <td width="45%">Part Id</td>
                                                <th width="55%"><?php echo  $wicam['dataWicam']['fileID']?></th>
                                            </tr>
                                            <tr>
                                                <td>Material</td>
                                                <th><?php echo  $wicam['dataWicam']['material']?></th>
                                            </tr>
                                            <tr>
                                                <td>Thickness</td>
                                                <th><?php echo $wicam['dataWicam']['thickness']?></th>
                                            </tr>
                                            <tr>
                                                <td>Length</td>
                                                <th><?php echo $wicam['dataWicam']['length']?></th>
                                            </tr>
                                            <tr>
                                                <td>Width</td>
                                                <th><?php echo $wicam['dataWicam']['width']?></th>
                                            </tr>
                                            <tr>
                                                <td>Net Area</td>
                                                <th><?php echo $wicam['dataWicam']['nettoArea']?></th>
                                            </tr>
                                            <tr>
                                                <td>Gross Area</td>
                                                <th><?php echo $wicam['dataWicam']['area']?></th>
                                            </tr>
                                            <tr>
                                                <td>Cuts</td>
                                                <th><?php echo $wicam['dataWicam']['cuts']?></th>
                                            </tr>
                                            <tr>
                                                <td>Bends</td>
                                                <th><?php echo $wicam['dataWicam']['bends']?></th>
                                            </tr>
                                            <tr>
                                                <td>Net Weight</td>
                                                <th><?php echo $wicam['dataWicam']['nettoWeight']?></th>
                                            </tr>
                                            <tr>
                                                <td>Gross Weight</td>
                                                <th><?php echo $wicam['dataWicam']['weight']?></th>
                                            </tr>
                                            <tr>
                                                <td>Cut Length</td>
                                                <th><?php echo $wicam['dataWicam']['cutLength']?></th>
                                            </tr>
                                            <tr>
                                                <td>Deburring</td>
                                                <th><?php echo $wicam['dataWicam']['deburring']?></th>
                                            </tr>
                                            <tr>
                                                <td>Grinding</td>
                                                <th><?php echo $wicam['dataWicam']['grinding']?></th>
                                            </tr>
                                        </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-card-container font-20">
                            <b>3 Mins 92 Seconds</b>
                    </div>
                </div>
            </div>
        </div>
    </div>