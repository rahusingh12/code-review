<?php
$query = $this->db->get('cart_details');
$ret['cartDetails'] = $query->result_array();

$jsonArr = json_decode($payAmount[0]);
?>
<style>
      .razorpay-payment-button {
        color: #ffffff !important;
        background-color: #7266ba;
        border-color: #7266ba;
        font-size: 14px;
        padding: 10px;
        display: none;
      }
       
    </style>
<!-- Body container Start -->
<div class="page-container">
    <div class="container">
        <div class="page-title-container">
            <div class="page-heading">Payment - Manufacturing  On-Demand</div>
            <div class="progress form-progress-bar">
                <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                </div>
            </div>
            <form class="form-container" name="#" id="course_enroll_form" method="post" action="<?php echo site_url()."additivemanufacturing/verify"?>" enctype="multipart/form-data">
                <!-- Box Start -->
                <div class="cart-list-container">
                    <?php foreach ($ret['cartDetails'] as $data){ ?>
                        <div class="row no-margin">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                <div class="cart-product-box-left">
                                    <img src="<?php echo base_url()."uploads/imagenot.jpg"?>" class="cart-product-img img-responsive" alt="img not found">

                                    <div class="cart-product-name-content">
                                        <div class="cart-product-name"><?php echo $data['name']; ?></div>
                                        <div class="cart-product-modal"><b>PART ID:</b> <?php echo $data['id']; ?></div>
                                        <div class="cart-product-modal"><b>MATERIAL:</b> <?php echo $data['material']; ?></div>
                                        <div class="cart-product-modal"><b>THICKNESS:</b><?php echo $data['thickness']; ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-7">
                                <div class="cart-product-box-right">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="product-body-info-set p-0">
                                                <span class="badge badge-pill mb-sm-1">Tag Name 1</span>
                                                <span class="badge badge-pill mb-sm-1">Tag Name 2</span>
                                                <span class="badge badge-pill mb-sm-1">Tag Name 3</span>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-2 col-md-3 col-lg-2 col-xl-4">
                                            <div class="cart-product-list-set">
                                                <div class="cart-product-list-title">Delivery Time</div>
                                                <div class="cart-product-list-price">
                                                    <select class="form-select-box">
                                                        <option value=""><?php echo $data['days']; ?>days</option>
                                                       
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-3 col-md-3 col-lg-3 col-xl-4">
                                             <div class="cart-product-list-set">
                                                <div class="cart-product-list-title">Price, INR</div>
                                                <div class="cart-product-list-price"><?php echo $data['price']; ?></div>
                                            </div>
                                        </div>
                                        <!-- <div class="col-6 col-sm-4 col-md-3 col-lg-4 col-xl-4">
                                            <div class="cart-product-list-set text-right">
                                                <button class="btn submit-btn">Remove</button>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    <?}?>
                </div>
                <!-- Box End -->
                <div class="cart-total">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6"></div>
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                            <div class="form-card-container">
                                <div class="row">
                                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 text-right">
                                        <ul>
                                            <li>Sub -Total</li>
                                            <li>Tax</li>
                                            <li>Discount</li>
                                            <li><b>Total</b></li>
                                        </ul>
                                    </div>
                                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 text-left">
                                        <ul>
                                            <li><b><?php echo $payAmount[1]['amount'] ?> INR</b></li>
                                            <li><b>0.00 INR</b></li>
                                            <li><b>0.00 INR</b></li>
                                            <li><b><?php echo $payAmount[1]['amount'] ?> INR</b></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="submit-btn-container">
                    <button class="btn submit-btn">Continue Shopping</button>
                    <button class="btn submit-btn">Confirm Order</button>
                </div>
                <script
                    src="https://checkout.razorpay.com/v1/checkout.js"
                    data-key="<?php echo $jsonArr->key ?>"
                    data-amount="<?php echo $jsonArr->amount ?>"
                    data-currency="INR"
                    data-name="<?php echo $jsonArr->name ?>"
                    data-image="<?php echo $jsonArr->image ?>"
                    data-description="<?php echo $jsonArr->description?>"
                    data-prefill.name="<?php echo $jsonArr->prefill->name?>"
                    data-prefill.email="<?php echo $jsonArr->prefill->email ?>"
                    data-prefill.contact="<?php echo $jsonArr->prefill->contact?>"
                    data-notes.shopping_order_id="3456"
                ></script>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="https://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        //quantity of course
        $( "#qty" ).change(function(e) {

            var participant_no = $(this).val();

            var coursePrice='<?php echo $data['price']; ?>';

            var totalPrice= parseInt(coursePrice)*parseInt(participant_no);

            document.getElementById('cartPrice').innerHTML = totalPrice;

        });
    });


</script>
