
<div class="page-container">
    <div class="container">
        <div class="page-title-container">
            <div class="page-heading">Payment - Manufacturing  On-Demand</div>
            <div class="progress form-progress-bar">
                <div class="progress-bar" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width:30%">
                </div>
            </div>
           <form class="form-container" id="event_enroll_form" method="post" action="<?php echo site_url()."additivemanufacturing/addcart" ?>" enctype="multipart/form-data">
                <!-- Box Start -->
                <div class="cart-list-container">
                    <?php  $i=0; ?>
                    <?php
                    foreach ($additiveCart as $data){ ?>
                        <div class="row no-margin" id="rowBlock<?= $i?>">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
                                <div class="cart-product-box-left"><?php
                                    if($data['product_type']=='course'){
                                        ?>
                                        <img src="<?php echo base_url()."uploads/remotetraining/".$data['image']?>" class="cart-product-img img-responsive" alt="img not found">

                                        <?
                                    }
                                    else if($data['product_type']=='additive'){?>
                                        <img src="<?php echo base_url()."uploads/imagenot.jpg"?>" class="cart-product-img img-responsive" alt="img not found">
                                    <? }
                                    else if($data['product_type']=='programming'){?>
                                        <img src="<?php echo base_url()."uploads/wicam/20190615190810.jpg"?>" class="cart-product-img img-responsive" alt="img not found">

                                    <? }
                                    else{ ?>
                                        <img src="<?php echo base_url()."uploads/event/".$data['image']?>" class="cart-product-img img-responsive" alt="img not found">
                                    <? 	}

                                    ?>


                                    <div class="cart-product-name-content">
                                        <div class="cart-product-name"><?php echo $data['name']; ?></div>
                                        <div class="cart-product-modal"><b>PART ID:</b>  <?php echo $data['id']; ?></div>
                                        <div class="cart-product-modal"><b>MATERIAL:</b><?php echo $data['material']; ?></div>
                                        <div class="cart-product-modal"><b>THICKNESS:</b><?php echo $data['thickness']; ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8">
                                <div class="cart-product-box-right">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="product-body-info-set p-0">
                                                <span class="badge badge-pill mb-sm-1">Tag Name 1</span>
                                                <span class="badge badge-pill mb-sm-1">Tag Name 2</span>
                                                <span class="badge badge-pill mb-sm-1">Tag Name 3</span>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-2 col-md-3 col-lg-2 col-xl-2">
                                            <div class="cart-product-list-set">
                                                <div class="cart-product-list-title">Qty</div>
                                                <div class="cart-product-list-price">
                                                    <select class="form-select-box quantity"  data-id="<?php echo $i?>" name="quantity[]">
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-2 col-md-3 col-lg-3 col-xl-3">
                                            <div class="cart-product-list-set">
                                                <div class="cart-product-list-title">Delivery Time</div>
                                                <div class="cart-product-list-price">
                                                    <select class="form-select-box">
                                                        <option value="">3 days</option>
                                                        <option value="">7 days</option>
                                                        <option value="">14 days</option>
                                                        <option value="">21 days</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-3 col-md-3 col-lg-2 col-xl-2">
                                            <div class="cart-product-list-set">
                                                <div class="cart-product-list-title">Price, INR</div>
                                                <div class="cart-product-list-price" id="singlePrice<?= $i;?>" name="priceINR">
                                                    <?php echo $data['price']; ?></div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-3 col-md-3 col-lg-2 col-xl-2">
                                            <div class="cart-product-list-set">
                                                <div class="cart-product-list-title">Price, INR</div>
                                                <div class="cart-product-list-price totalprice" id="cartPrice<?php echo $i?>" name="cartPrice"><?php echo $data['price']; ?></div>
                                                <input type="hidden" name="cartPrice[]" id="cartPrice<?php echo $i?>" value="<?php echo $data['price']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-4 col-md-3 col-lg-3 col-xl-3">
                                            <div class="cart-product-list-set text-right">
                                                <input type="hidden" name="cart_id[]" id="cart_id<?php echo $i?>" value="<?php echo $data['cart_id']; ?>">
                                                <button type="button" name="remove" class="btn submit-btn remove_inventory" data-type = "<?php echo $data['cart_id']; ?>" data-id="<?= $i?>" id="'.$data['rowid'].'">Remove</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?
                        $i++;
                    }?>
                </div>
                <!-- Box End -->
                <!-- Box Start -->

                <!-- Box End -->
                <div class="cart-total">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6"></div>
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                            <div class="form-card-container">
                                <div class="row">
                                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 text-right">
                                        <ul>
                                            <li>Sub -Total</li>
                                            <li>Tax</li>
                                            <li>Discount</li>
                                            <li><b>Total</b></li>
                                        </ul>
                                    </div>
                                    <div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 text-left">
                                        <ul>
                                            <li><b id="subTotal" name="SubINR" value="">0.0</b></li>
                                            <input type="hidden" name="SubINR1" id="subTotal1">
                                            <li><b>0.00 INR</b></li>
                                            <li><b>0.00 INR</b></li>

                                            <li><b id="final_total" value=" ">  INR</b></li>
                                            <input type="hidden" name="SubIN" id="final_total">
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="submit-btn-container">
                    <a href="<?php echo site_url() . "digitalmanufacturing/" ?>" class="btn submit-btn">Continue Shopping</a>

                    <?php if($this->session->userdata('uid')){
                        $userid= $this->session->userdata('uid');
                        $url = site_url()."/customer/api/findSingle/$userid";
                        $userData =  apiCall($url, "get");
                        $userData=$userData['result'];
                        ?>
                        <button class="btn submit-btn" name="btnCheckouteve" type="submit" id="btnCheckout">Checkout</button></a>
                    <?php }else{?>
                        <a href="" data-toggle="modal" data-target="#login-modal">
                            <button class="btn adv-search btn_orange btn submit-btn">Checkout</button></a>
                    <?php }?>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="https://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
    function calculateSubtotal(){
        $total=0;
        $(".cart-product-box-right").each(function(){
            $q=$(this).find(".quantity").val()
            //alert($q)
            id=$(this).find(".quantity").data("id");
            single=$("#singlePrice"+id).text();
            $subtotal=parseInt($q)*parseInt(single);
            $("#cartPrice"+id).text($subtotal)
            $total+=$subtotal;
        });
        $("#subTotal").text($total)
        $('#subTotal1').val($total);
        var final_total= document.getElementById("subTotal1").value;

        document.getElementById("final_total").innerHTML=final_total


    }


    $(document).on("change",".quantity",function(){

        calculateSubtotal();

    })

    $(document).ready(function() {

        var sum = 0;
        $('.totalprice').each(function(){

            sum += parseFloat($(this).text());  // Or this.innerHTML, this.innerText
            console.log(sum);
            $('#subTotal').text(sum);
            $('#subTotal1').val(sum);

            var final_total= document.getElementById("subTotal1").value;

            document.getElementById("final_total").innerHTML=final_total

        });
        $(document).on('click', '.remove_inventory', function(){
            if(confirm("Do you want to delete this product from cart ?"))
                dataId=$(this).data("id");
            id = $(this).attr('data-type');
            $.ajax({
                url:"<?php echo site_url(); ?>events/removeItem",
                method:"POST",
                data:{row_id:id},
                success:function(data)
                {
                    //alert("lkhl");
                    $("#rowBlock"+dataId).remove()
                    calculateSubtotal()
                }
            });
        });

    });
</script>
