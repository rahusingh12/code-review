<link rel="stylesheet" href="<?=$theme_url;?>/plugins/datatables/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?=$theme_url;?>/css/toastr.css">
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
	<section class="content-header">
	  <span style="font-size: 24px;padding: 10px;">Machine On Demand #<?php echo $rfq_id; ?> - Assign Supplier</span>
	  <ol class="breadcrumb">
		<li><a href="<?=site_url()."dashboard"?>"><i class="fa fa-dashboard"></i> Home</a></li>
		<li class=""><a href="<?=site_url('additivemanufacturing/admin/RequestList')?>">Machine On Demand RFQ List</a></li>
	  </ol>
	</section>
 <!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
					<div class="box-body"> 
						<form id="req_cons" name="req_cons" class="form-horizontal" enctype="multipart/form-data" method="post">
							<div class="">
					
								<table class="table table-bordered table-striped" id="">
									<thead>
										<tr>
											<th>uid</th>
											<th>Supplier Name</th>  
											<th>Email</th>  
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									<?php foreach($supplier_user_list as $rowData) { ?>
										<tr>
											<td><?=$rowData['uid']?></td>
											<td><?=$rowData['u_name']?></td>
											<td><?=$rowData['u_email']?></td>
											<td>
											<a class="btn btn-primary btn-xs" href="<?php echo site_url('additivemanufacturing/admin/assign-supplier/'.$rfq_id.'/'.$rowData['uid']); ?>">Assign</a>
											</td>
										</tr>	
									<?php } ?>
									</tbody>
								</table>  
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>			
	</section> 
</div>
	  
<?php $this->template->contentBegin(POS_BOTTOM);?>
	<script src="<?=$theme_url;?>/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?=$theme_url;?>/plugins/datatables/dataTables.bootstrap.min.js"></script> 
	<script type="text/javascript">
	$(document).ready(function() {
		$("#consultant_table").DataTable({
	});	
	}); 
	</script>
<?php $this->template->contentEnd(); ?> 