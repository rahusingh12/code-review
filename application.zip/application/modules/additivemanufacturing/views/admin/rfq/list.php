<link rel="stylesheet" href="<?=$theme_url;?>/plugins/datatables/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?=$theme_url;?>/css/toastr.css">
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
	<section class="content-header">
	  <span style="font-size: 24px;padding: 10px;">Additive Manufacturing Request List</span>
	  <ol class="breadcrumb">
		<li><a href="<?=site_url()."dashboard"?>"><i class="fa fa-dashboard"></i> Home</a></li>
		<li class=""><a href="<?=site_url()."events/admin"?>">Additive Manufacturing Request List </a></li>
		
	  </ol>
	</section>
 <!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-xs-12">
				<div class="box">
						<?php 	// display messages
							if(hasFlash("dataMsgSuccess"))	{	?>
								<div class="alert alert-success alert-dismissible" role="alert">
								  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								  <?php echo getFlash("dataMsgSuccess"); ?>
								</div>
					<?php	}	?>
						<?php 	// display messages
							if(hasFlash("dataMsgError"))	{	?>
								<div class="alert alert-warning alert-dismissible" role="alert">
								  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								  <?php echo getFlash("dataMsgError"); ?>
								</div>
					<?php	}	?>
					 
					<div class="box-body"> 
						<form id="" name="" class="form-horizontal" enctype="multipart/form-data" method="post">
							<div class="table-responsive">
					
								<table class="table table-bordered table-striped" id="community_table">
									<thead>
										<tr>
											<th>RFQ</th>
											<th>Customer</th> 
											<th>Part Name</th> 
											<th>Material</th>
											<th>NDA</th> 
                                            <th>Quote</th> 
											<th>Request On</th> 
											<th>Supplier</th>
											<th>Work Order</th> 
                                            <th>Supplier Invoice</th> 
										</tr>
									</thead>
									<tbody>
									<?php 
									$i=1;
										foreach($requestList as $row){ ?>
										<tr>
											<td><?=$row['dmr_id']?></td>
											<td><?=$row['customer_name']; ?></td>
											<td>
												<?php echo $row['part_name']; ?><br>
                                                <?php if (!empty($row['part_description'])) { ?>
                                                    <b>Part Description:</b> <?php echo $row['part_description']; ?>
                                                <?php } ?>
											</td>
											<td>
												<?php echo $row['material']; ?><br>
                                                <b>Thickness:</b> <?php echo $row['thickness']; ?><br>
                                                <b>Rotation:</b> <?php echo $row['rotation']; ?><br>
                                                <b>No of Parts:</b> <?php echo $row['no_of_parts']; ?>
											</td>
											<td>
                                                <?php if(!empty($row['nda'])) { ?>
                                                    <a target="_blank" href="<?=site_url($row['nda']);?>" class="btn btn-xs btn-primary">View NDA</a>
                                                <?php } else { ?>
                                                    NA
                                                <?php } ?>

                                            </td>
                                            <td>
                                                <?php echo $row['quote']; ?>
                                            </td> 
											<td><?=$row['requested_date']; ?></td>
											<td>
                                                <?php if(!empty($row['supplier_id'])) {
													echo $row['supplier_name'];
												} else { ?>
													<a href="<?=site_url('additivemanufacturing/admin/supplier-list/'.$row['dmr_id']);?>" class="btn btn-xs btn-primary">Assign</a>
												<?php } ?>
											</td>
											<td>

										        <?php if(!empty($row['work_order'])) { ?>
                                                    <a target="_blank" href="<?=site_url($row['work_order']);?>" class="btn btn-xs btn-primary">View Work Order</a>

                                                    <br>
                                                    Uploaded <?php echo $row['work_order_uploaded']; ?>
                                                <?php } else { ?>
                                                    <a href="<?=site_url('additivemanufacturing/admin/upload-doc/work_order/'.$row['dmr_id']);?>" class="btn btn-xs btn-primary">Upload</a>
                                                <?php } ?>

											</td>
                                            <td>

                                                <?php if(!empty($row['supplier_invoice'])) { ?>
                                                    <a target="_blank" href="<?=site_url($row['supplier_invoice']);?>" class="btn btn-xs btn-primary">View Supplier Invoice</a>

                                                    <br>
                                                    Uploaded <?php echo $row['supplier_invoice_uploaded']; ?>
                                                <?php } else { ?>
                                                    <a href="<?=site_url('additivemanufacturing/admin/upload-doc/supplier_invoice/'.$row['dmr_id']);?>" class="btn btn-xs btn-primary">Upload</a>
                                                <?php } ?>
                                                
                                            </td>
										</tr>
										<? } ?>
									</tbody>
								</table>  
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>			
	</section> 
</div>
	
	  
<?php $this->template->contentBegin(POS_BOTTOM);?>
	<script src="<?=$theme_url;?>/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?=$theme_url;?>/plugins/datatables/dataTables.bootstrap.min.js"></script> 
	<script type="text/javascript">
	$(document).ready(function() {
		$("#community_table").DataTable({
	});	
	}); 
	</script>
<?php $this->template->contentEnd();	?> 