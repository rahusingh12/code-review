<?php
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Additivemanufacturing extends FRONTEND_Controller {

    // constructor
    function __construct() {
        // parent constructor
        parent::__construct();
     $this->load->model('additivemanufacturing_model');
     $this->load->library('cart');
        //$this->load->model("pages_model");
    }
	public function index(){
		$arrData=array(
		);
		$this->template->load("index",$arrData);
	}
	public function about()	{
		// redirect to about
		$this->template->load("about" );
	}
	public function contact()	{
		// redirect to contact
		$this->template->load("contact" );
	}
	public function disclaimer()	{
		// redirect to disclaimer
		$this->template->load("disclaimer" );
	}
	public function privacy_statement()	{
		// redirect to privacy_statement
		$this->template->load("privacy_statement" );
	}
	public function refund_policy()	{
		// redirect to refundPolicy
		$this->template->load("refund_policy" );
	}
	public function terms_conditions()	{
		// redirect to terms_conditions
		$this->template->load("terms_conditions" );
	}
	public function terms_of_use()	{
		// redirect to terms_of_use
		$this->template->load("terms_of_use" );
	}
	public function media()	{
		// redirect to media
		$this->template->load("media" );
	}
	public function join_our_forum()	{
		// redirect to join_our_forum
		$this->template->load("join_our_forum" );
	}
	public function site_map()	{
		// redirect to site_map
		$this->template->load("site_map" );
	}
	public function remote_programming()	{
		// redirect to remote_programming
		$this->template->load("remote_programming" );
	}



	public function additive_manufacturing()	{


			if(isset($_POST['btnMachineVideo'])){
							//print_r("Hello");exit;
							$pageData = $this->input->post();
							$pageData['customer_id']	= $this->session->userdata('uid');
							$pageData['requested_date']	= date('Y-m-d');;

							$url = site_url()."groupbuying/api/videoChatRequest";
							$response =  apiCall($url, "post",$pageData);
							if($response['result']){
								setFlash("dataMsgSuccess", $response['message']);
								redirect(site_url()."additivemanufacturing/additive_manufacturing");
							}
				}

		$url = site_url()."additivemanufacturing/api/findMultipleAdditiveManufacturing";
		$additive_manufacturing_list =  apiCall($url, "get");
		 //print_r($additive_manufacturing_list);exit;

		$url = site_url()."additivemanufacturing/api/findMultipleAdditiveManufacturingProcesses";
		$additive_manufacturing_processes_list =  apiCall($url, "get");

		$url = site_url()."additivemanufacturing/api/findMultiplePrintingMaterials3D";
		$printing_materials3D_list =  apiCall($url, "get");
		//print_r($printing_materials3D_list);exit;

		$url = site_url()."additivemanufacturing/api/findMultiplePrintingApplication";
		$additive_manufacturing_printing_application =  apiCall($url, "get");

		  $arrData=array(
		  	'additive_manufacturing_list'=>$additive_manufacturing_list['result'],
		  	'additive_manufacturing_processes_list'=>$additive_manufacturing_processes_list['result'],
		  	'printing_materials3D_list'=>$printing_materials3D_list['result'],
		  	'additive_manufacturing_printing_application'=>$additive_manufacturing_printing_application['result']);

		// redirect to laser_processing
		$this->template->load("additive_manufacturing" ,$arrData);
	}

    public function additive_manufacturingRFQSelect() {

        if(isset($_POST['radio1'])) {
            if ($_POST['radio1'] == 'sheet-metal') {
                redirect('additivemanufacturing/additive_manufacturingRFQ');
            }
            if ($_POST['radio1'] == '3d-print') {
                redirect('additivemanufacturing/additive_manufacturingRFQ');
            }
            if ($_POST['radio1'] == 'cnc-machine') {
                redirect('additivemanufacturing/additive_manufacturingRFQ');
            }
        }

        $this->template->load("select");
    }

    public function additive_manufacturingRFQ() {

        $this->load->library("wicamlib");

        $data = [];
        $data['material'] = ['Material A', 'Material B', 'Material C'];
        $data['thickness'] = ['0.5 mm','1.5 mm','2.0 mm','2.5 mm','3.0 mm','3.5 mm','4.0 mm','4.5 mm','5.0 mm','5.5 mm','6.0 mm'];
        $data['rotation'] = ['Option A', 'Option B'];
        
        $this->form_validation->set_rules('part_name', 'Part Name', 'required|trim|max_length[100]');
        $this->form_validation->set_rules('material', 'Material Type', 'required|in_list['.implode(',', $data['material']).']');
        $this->form_validation->set_rules('thickness', 'Thickness', 'required|in_list['.implode(',', $data['thickness']).']');
        $this->form_validation->set_rules('rotation', 'Rotation', 'required|in_list['.implode(',', $data['rotation']).']');
        $this->form_validation->set_rules('no_of_parts', 'Number of Parts', 'required|is_natural');
        $this->form_validation->set_rules('part_description', 'Part Description', 'trim');

        $this->form_validation->set_rules('nda_required', 'Non - Disclosure', 'required|in_list[Y,N]');

        if ($this->form_validation->run()) {
            $manufacture_request = [];

            $manufacture_request['customer_id'] = $this->session->userdata('uid');

            $manufacture_request['part_name'] = set_value('part_name');
            $manufacture_request['material'] = set_value('material');
            $manufacture_request['thickness'] = set_value('thickness');
            $manufacture_request['rotation'] = set_value('rotation');
            $manufacture_request['no_of_parts'] = set_value('no_of_parts');
            $manufacture_request['part_description'] = set_value('part_description');
            $manufacture_request['nda_required'] = set_value('nda_required');

            $config['upload_path']          = './uploads/on-demand';
            $config['allowed_types']        = 'pdf';
            $config['encrypt_name']         = TRUE;
            
            $this->load->library('upload');
            $this->upload->initialize($config);

            if ($manufacture_request['nda_required'] == 'Y')
            {
                if ( ! $this->upload->do_upload('nda_file'))
                {
                    setFlash("dataMsgError", $this->upload->display_errors());
                }
                else
                {
                    $upload_data = $this->upload->data();
                    $manufacture_request['nda'] = 'uploads/on-demand/'.$upload_data['file_name'];
                }
            }

            $config['allowed_types']        = 'dwg|dxf';

            $this->upload->initialize($config);

            if ( ! $this->upload->do_upload('attach_drawing'))
            {
                setFlash("dataMsgError", $this->upload->display_errors());
            }
            else
            {
                $upload_data = $this->upload->data();
                $attach_drawing_full_path = $upload_data['full_path'];
                $manufacture_request['attach_drawing'] = 'uploads/on-demand/'.$upload_data['file_name'];
            }


            if (($manufacture_request['nda_required'] == 'N' OR ($manufacture_request['nda_required'] == 'Y' AND isset($manufacture_request['nda'])))
                AND isset($manufacture_request['attach_drawing']))
            {
                $this->load->model('additivemanufacturing/additivemanufacturing_model');
                $rfq_id = $this->additivemanufacturing_model->createRfq($manufacture_request);


                $wicam_data=json_decode(json_encode(json_decode($this->wicamlib->apiFileUpload($attach_drawing_full_path))),true);

                $p_data= $wicam_data['price'];
                $price = number_format($p_data, 2, '.', '');
                
                if(isset($wicam_data['error'])) {
                    unset($wicam_data['error']);
                }

                $wicam_data['dmr_id'] = $rfq_id;
                $wicam_data['rfq_type']="additive manufacturing";

                $this->session->set_userdata('dataWicam',$wicam_data);
                $this->db->insert('wicam_api', $wicam_data);

                // cart 
                  
                $cardAdd['p_id']=$wicam_data['fileID'];
                $cardAdd['price']=$price;
                $cardAdd['name']=$wicam_data['rfq_type'];
                $cardAdd['image']=$img;
                $cardAdd['material']=$wicam_data['material'];
                $cardAdd['thickness']=$wicam_data['thickness'];
                $cardAdd['product_type']="additive";


                $this->db->insert('cart_details', $cardAdd);
                $eventRowID = $this->db->insert_id();
                 
                $query = $this->db->get('cart_details');
                $ret['additiveCart'] = $query->result_array();

                $this->template->load("additive_cart",$ret);
                return;
            }
        }
        else {
            setFlash("dataMsgError", validation_errors());
        }

        $this->template->load("additive_manufacturingRFQ", $data);
     }

     Public function addcart(){
         
        $query = $this->db->get('cart_details');
            $ret = $query->result_array();
            $evid=$ret[0]['p_id'];
            
        if (isset($_POST['btnCheckouteve'])) {
            $cart_data=$this->input->post();
           

            foreach($cart_data as $i => $data){
                if($i == 'cart_id'){
                    foreach($data as $k =>$single){
                        $data1 = array(
                            'qty' => $cart_data['quantity'][$k],
                            'price' => $cart_data['cartPrice'][$k],
                            'days' => $cart_data['days'][$k]
                            );
                        $this->db->where('cart_id', $single);
                        $this->db->update('cart_details',$data1);
                    }
                }
         
                
            }
            $cart_data['Finalamount']=$this->input->post();
            // echo "<pre>";
            // print_r("done");exit();
            $this->template->load("additive_billing",$cart_data);
        }
        else if (isset($_POST['submitData'])) {
            $checkout = $this->input->post();
            // echo "<pre>";
            // print_r($checkout); exit();

            $checkoutdata = array(
                'bill_firstname'  => $checkout['fname'],
                'bill_lastname'   => $checkout['lname'],
                'bill_companyname'=> $checkout['cname'],
                'billingadd1'     => $checkout['address1'],
                'billingadd2'     => $checkout['address2'],
                'billingcity'     => $checkout['city'],
                'billingstate'    => $checkout['state'],
                'billingPostcode' => $checkout['postcode'],
                'billingCountry'  => $checkout['country'],
                'deliveryadd1'    => $checkout['delivery_add1'],
                'deliveryadd2'    => $checkout['delivery_add2'],
                'delverycity'     => $checkout['delivery_city'],
                'deliverystate'   => $checkout['delivery_state'],
                'deliverypostcode'=> $checkout['delivery_postcode'],
                'deliverycountry' => $checkout['delivery_country'],
                'amount'    => $checkout['amount'],
            );

    
            //print_r($checkout['amount']); exit();

            $amount=$checkout['amount'];
            $payment=$this->payment($amount);
           

            $this->session->set_userdata('additive',$checkoutdata);

            $this->session->get_userdata($checkoutdata);
            $data['payAmount']=array($payment,$checkout);

            $this->template->load("additive_checkout",$data);
        }
        
    }

   
	

    Function quoteMail(){
        // Load PHPMailer library
        $this->load->library('phpmailer_lib');

        // PHPMailer object
        $mail = $this->phpmailer_lib->load();

        // SMTP configuration
       $mail->isSMTP();
        $mail->Host     = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ducatgaurav@gmail.com';
        $mail->Password = 'ffendlcoqbbqdued';
        $mail->SMTPSecure = 'ssl';
        $mail->Port     = 465;

        $mail->setFrom('pixelcrayons2@gmail.com', 'pixelcrayons');
        //$mail->addReplyTo('rahul.singh@mail.vinove.com', 'pixelcrayons');

        // Add a recipient
       $mail->addAddress('rahul.singh@mail.vinove.com');

        
        // Email subject
        $mail->Subject = 'Additive Manufacturing Quote Request';

        // Set email format to HTML
        $mail->isHTML(true);

        // Email body content
        $dataW['wicam'] = $this->session->userdata($wicam_data);
        
       
        
        $mailContent = $this->load->view('email_template',$dataW,true);

        // "<h3>Machine Time Study Request</h3>
        //                 <p>Machine Time study request successfully submitted.Find below mention details:-</p>
        //                 <p>File Id:</p>". $wicam_data['fileID'];

        $mail->Body = $mailContent;

//print_r($mail->send()); exit();
        // Send email

        if(!$mail->send()){
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            echo '';
        }
      }
           




            public function manufacturing_import() {

        if (isset($_POST["import"])) {
            $filename = $_FILES["file"]["tmp_name"];
            //$config['allowed_types'] = 'gif|jpg|jpeg|png|pdf|bmp';
          //$config['allowed_types'] = '*';
                 //echo"hi";die();
            if ($_FILES["file"]["size"] > 0) {
                $file = fopen($filename, "r");
                while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE) {
                    $data = array(
                        'additive_manufacturing_id' => $importdata[1],
                        'additive_manufacturing_name' => $importdata[2],
                        'additive_manufacturing_description' => $importdata[3],
                        'additive_manufacturing_image' => $importdata[4]
                    );
//                     echo "<pre>";
//                      print_r($data);die;
                    $insert = $this->additivemanufacturing_model->insertCSV($data);
                }
                fclose($file);
                $this->session->set_flashdata('message',
                        'Data are imported successfully..');
               	$this->template->load("additive_manufacturing");

            } else {
                $this->session->set_flashdata('message',
                        'Something went wrong..');
                $this->template->load("additive_manufacturing");

            }
        }
    }

    // user log


	public function user_log($data) {
        //  echo 'hi';die;
        //print_r($data);die;
        $pageData['transaction_type'] = $data;
        $pageData['uid'] = $this->session->userdata('uid');

        //print_r($pageData);die;
        $url = site_url() . "/customer/api/insertUserLog";
        $response = apiCall($url, "post", $pageData);
        //print_r($response);die;
    }

    public function additive_billing(){
         $this->template->load("additive_billing", $arrData);
    }

    public function payment($amount){
       

        $api = new Api(RAZOR_KEY_ID, RAZOR_KEY_SECRET);
         
             
        $orderData = [
            'receipt'         => 3456,
            'amount'          => $amount * 100, // 2000 rupees in paise
            'currency'        => 'INR',
            'payment_capture' => 1 // auto capture
        ];
      
        $razorpayOrder = $api->order->create($orderData);

        $razorpayOrderId = $razorpayOrder['id'];

        $_SESSION['razorpay_order_id'] = $razorpayOrderId;

        $amount = $orderData['amount'];
    

        $data = [
            "key"               => RAZOR_KEY_ID,
            "amount"            => $amount,
            "name"              => "Teranex",
            "description"       => " Pay with Razorpay",
            "image"             => "http://www.teranexbeta.n2.iworklab.com/themes/site/images/logo.jpg",
            "prefill"           => [
            "name"              => "",
            "email"             => "",
            "contact"           => "",
            ],
            
            "theme"             => [
            "color"             => "#F37254"
            ],
            "order_id"          => $razorpayOrderId,
        ];
        
        
        $json = json_encode($data);
        return $json;
       
    }
    public function verify(){
        
       
        $data["additiveRfq"] = $this->session->userdata('additive');
        $lastRow = $this->session->userdata('rowLastId');
        

        $userDetails = $this->session->userdata(); 
            
        $additiveManu=array_merge($data,$userDetails);
        
        $success = true;
  
        $error = "Payment Failed";

        if (empty($_POST['razorpay_payment_id']) === false){            
            $api = new Api(RAZOR_KEY_ID, RAZOR_KEY_SECRET);
       
            try {
                // Please note that the razorpay order ID must
                // come from a trusted source (session here, but
                // could be database or something else)
                $attributes = array(
                    'razorpay_order_id' => $_SESSION['razorpay_order_id'],
                    'razorpay_payment_id' => $_POST['razorpay_payment_id']                
                );
               
                
            }
            catch(SignatureVerificationError $e){
            $success = false;
            $error = 'Razorpay Error : ' . $e->getMessage();
            }
       }

        if ($success === true){  
       
                $payment = $api->payment->fetch($_POST['razorpay_payment_id']);
                $additiveData['user_id']=$additiveManu['uid'];
                $additiveData['rfq_row_id']=$lastRow;
                $additiveData['user_name']=$additiveManu['u_name'];
                $additiveData['user_email']=$additiveManu['user_email'];  
                $additiveData['rmpgm_amount']=$additiveManu['additive']['amount'];         
                $additiveData['total_amount']=$additiveManu['additive']['amount'];
                $additiveData['payment_status']="S";
                $additiveData['razorpay_payment_id']=$_POST['razorpay_payment_id'];

                $this->db->insert('additive_rfq_payment', $additiveData);
                $addRowID = $this->db->insert_id();
                
                    
                $dataDelivery['ref_id']=$addRowID;
                $dataDelivery['type']="additiveRfq";
                $dataDelivery['bill_firstname']=$additiveManu['additiveRfq']['bill_firstname'];
                $dataDelivery['bill_lastname']=$additiveManu['additiveRfq']['bill_lastname'];
                $dataDelivery['bill_companyname']=$additiveManu['additiveRfq']['bill_companyname'];
                $dataDelivery['address1']=$additiveManu['additiveRfq']['billingadd1'];
                $dataDelivery['address2']=$additiveManu['additiveRfq']['billingadd2'];
                $dataDelivery['city']=$additiveManu['additiveRfq']['billingcity'];
                $dataDelivery['state']=$additiveManu['additiveRfq']['billingstate'];
                $dataDelivery['postcode']=$additiveManu['additiveRfq']['billingPostcode'];
                $dataDelivery['country']=$additiveManu['additiveRfq']['billingCountry'];
                $dataDelivery['delivery_add1']=$additiveManu['additiveRfq']['deliveryadd1'];
                $dataDelivery['delivery_add2']=$additiveManu['additiveRfq']['deliveryadd2'];
                $dataDelivery['delivery_city']=$additiveManu['additiveRfq']['delverycity'];
                $dataDelivery['delivery_state']=$additiveManu['additiveRfq']['deliverystate'];
                $dataDelivery['delivery_postcode']=$additiveManu['additiveRfq']['deliverypostcode'];
                $dataDelivery['delivery_country']=$additiveManu['additiveRfq']['deliverycountry'];


                $this->db->insert('delivery_payment_details', $dataDelivery);
                
                $this->db->truncate('cart_details'); 
                
                //$capture = $api->payment->fetch($payment['id'])->capture(array('amount'=> $payment['amount']));
                //print_r($capture); exit();
                
                            
                $html = "<p>Your payment was successful</p>
                        <p>Payment ID: {$_POST['razorpay_payment_id']}</p>";
        }
        else{
         
            $html = "<p>Your payment failed</p>
                    <p>{$error}</p>";
        }
        
        $this->quoteMail();
       
        $dataW['wicam'] = $this->session->userdata($wicam_data);
       
         
       $this->template->load("additiveManuRequest_submitted",$dataW);

    }
    public function removeItem($rowid){
            
        // Remove item from cart
        $remove = $this->cart->remove($rowid);
        // Redirect to the cart page
        $this->template->load("event_cart");
    }
}
