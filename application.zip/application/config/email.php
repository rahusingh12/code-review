<?php

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'ssl://smtp.gmail.com';
$config['smtp_user'] = 'pixelcrayons2@gmail.com';
$config['smtp_pass'] = 'isjfomqnlllxaozb';
$config['smtp_port'] = 465;

$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";
?>
