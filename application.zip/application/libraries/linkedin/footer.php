<!-- blog promotion starts -->
<div class="margin10"></div>
<div class="row">
 
  

<!-- blog promotion ends -->
</div>




<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
<?php
$DB = NULL;
?>
