<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_PHPMailer {
    public function Email_PHPMailer() {
        require_once('PHPMailer/PHPMailerAutoload.php');
    }
}