<?PHP
/*
 * @author Puneet Mehta
 * @website: http://www.PHPHive.info
 * @facebook: https://www.facebook.com/pages/PHPHive/1548210492057258
 */
?>
<BR><BR>
<center>
<!-- blog promotion starts -->
<div class="row">
    <iframe src="//www.facebook.com/plugins/likebox.php?href=https://www.facebook.com/pages/PHPHive/1548210492057258&amp;width&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=198210627014732" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true"></iframe>
    <div class="padding10 clearfix"></div>
</div>
<!-- blog promotion ends -->
</center>
</div>
<!-- Google Analytics -->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-56241980-1', 'auto');
  ga('send', 'pageview');

</script>

<!-- Google Analytics -->
<footer>
  <div class="navbar navbar-inverse footer">
    <div class="container-fluid">
      <div class="copyright">
        <a href="http://www.phphive.info" target="_blank">&copy; www.PHPHive.info  2014 | All rights reserved</a>
      </div>
    </div>
  </div>
</footer>


<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
<?php
$DB = NULL;
?>