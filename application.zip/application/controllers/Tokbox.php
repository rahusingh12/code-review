<?php
/**
 * Created by PhpStorm.
 * User: krishan
 * Date: 19/3/19
 * Time: 12:01 PM
 */

class Tokbox  extends MX_Controller
{
    function index(){
        print_r('fafafafafafafa');exit();
        $this->load->view("tokbox/index");
    }

}