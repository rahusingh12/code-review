<?php

class sessionSecurity
{

    var $CI;

    function __construct()
    {
        $this->CI =& get_instance();
        // $this->CI->load->helper('url');
        $this->CI->load->library('session');
        $this->CI->load->library('input');

    }

    public function sessionValidation()
    {
       // inactive in seconds
        $inactive = 600;
        if( !isset($_SESSION['timeout']) )
        $_SESSION['timeout'] = time() + $inactive; 
        

        $session_life = time() - $_SESSION['timeout'];

        

        if($session_life > $inactive)
        {  
            session_destroy(); 
           redirect("/");     }

        $_SESSION['timeout']=time();


    }
}
 